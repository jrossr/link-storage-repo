<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) exit("Not logged in");

$user_id = $_SESSION['user_id'];

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=links.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['Title', 'URL', 'Tags']);

$stmt = $db->prepare("SELECT title, url, tags FROM links WHERE user_id = ?");
$stmt->execute([$user_id]);
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, $row);
}
fclose($output);
exit;