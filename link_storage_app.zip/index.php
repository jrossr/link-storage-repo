<?php
session_start();
require 'db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$search = $_GET['search'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['title'] && $_POST['url']) {
    $stmt = $db->prepare("INSERT INTO links (title, url, tags, user_id) VALUES (?, ?, ?, ?)");
    $stmt->execute([$_POST['title'], $_POST['url'], $_POST['tags'], $user_id]);
    header("Location: index.php");
    exit;
}

if (isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM links WHERE id = ? AND user_id = ?");
    $stmt->execute([$_GET['delete'], $user_id]);
    header("Location: index.php");
    exit;
}

$query = "SELECT * FROM links WHERE user_id = ? AND (title LIKE ? OR url LIKE ? OR tags LIKE ?) ORDER BY id DESC";
$stmt = $db->prepare($query);
$stmt->execute([$user_id, "%$search%", "%$search%", "%$search%"]);
$links = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head><title>My Link Storage</title><link rel="stylesheet" href="style.css"></head>
<body>
<h1>🔗 Link Storage</h1>
<a href="logout.php">Logout</a> | <a href="export.php">Export CSV</a>

<form method="POST">
    <input name="title" placeholder="Title" required>
    <input name="url" placeholder="https://..." required>
    <input name="tags" placeholder="Tags (comma-separated)">
    <button type="submit">Add</button>
</form>

<form method="GET">
    <input name="search" placeholder="Search..." value="<?= htmlspecialchars($search) ?>">
    <button type="submit">🔍</button>
</form>

<ul>
<?php foreach ($links as $link): ?>
    <li>
        <a href="<?= htmlspecialchars($link['url']) ?>" target="_blank"><?= htmlspecialchars($link['title']) ?></a>
        <small><?= htmlspecialchars($link['tags']) ?></small>
        <a class="delete" href="?delete=<?= $link['id'] ?>">🗑️</a>
    </li>
<?php endforeach; ?>
</ul>
</body>
</html>