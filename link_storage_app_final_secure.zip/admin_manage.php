<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    echo "Access denied.";
    exit;
}

if (isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM links WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    header("Location: admin_manage.php");
    exit;
}

$all_links = $db->query("SELECT links.id, links.title, users.username FROM links JOIN users ON links.user_id = users.id ORDER BY links.id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Link Manager</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h1>🧹 Admin Link Management</h1>
    <ul class="list-group">
    <?php foreach ($all_links as $link): ?>
        <li class="list-group-item d-flex justify-content-between align-items-center">
            <?= htmlspecialchars($link['title']) ?> <small>by <?= htmlspecialchars($link['username']) ?></small>
            <a href="?delete=<?= $link['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
        </li>
    <?php endforeach; ?>
    </ul>
</body>
</html>
