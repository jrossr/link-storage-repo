<?php
require 'db.php';
header('Content-Type: application/json');

$auth = $_GET['token'] ?? '';
$user = $db->prepare("SELECT id FROM users WHERE api_token = ?");
$user->execute([$auth]);
$user_id = $user->fetchColumn();

if (!$user_id) {
    echo json_encode(["error" => "Unauthorized"]);
    http_response_code(401);
    exit;
}

$stmt = $db->prepare("SELECT title, url, tags, clicks FROM links WHERE user_id = ?");
$stmt->execute([$user_id]);
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
