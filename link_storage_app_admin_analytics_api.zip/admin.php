<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Only allow admin user (e.g., user ID 1)
if ($_SESSION['user_id'] != 1) {
    echo "Access denied.";
    exit;
}

// Total users
$total_users = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();

// Total links
$total_links = $db->query("SELECT COUNT(*) FROM links")->fetchColumn();

// Top clicked links
$top_links = $db->query("SELECT title, clicks FROM links ORDER BY clicks DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h1>🛠 Admin Dashboard</h1>
    <p><strong>Total Users:</strong> <?= $total_users ?></p>
    <p><strong>Total Links:</strong> <?= $total_links ?></p>

    <h3>🔥 Top Clicked Links</h3>
    <ul class="list-group">
        <?php foreach ($top_links as $link): ?>
            <li class="list-group-item d-flex justify-content-between">
                <?= htmlspecialchars($link['title']) ?>
                <span class="badge bg-primary"><?= $link['clicks'] ?> clicks</span>
            </li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
