<?php
session_start();
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    try {
        $stmt = $db->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->execute([$username, $password]);
        $_SESSION['user_id'] = $db->lastInsertId();
        header("Location: index.php");
        exit;
    } catch (PDOException $e) {
        $error = "Username already taken.";
    }
}
?>
<!DOCTYPE html>
<html><head>
    <meta charset="UTF-8">
    <title>Link Storage</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>📝 Register</h2>
<?php if (!empty($error)) echo "<p>$error</p>"; ?>
<form method="POST">
    <input name="username" placeholder="Choose a username" required>
    <input name="password" type="password" placeholder="Choose a password" required>
    <button type="submit">Register</button>
</form>
</body>
</html>