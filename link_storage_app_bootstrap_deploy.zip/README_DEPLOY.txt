# Link Storage App Deployment Guide (Linux Server)

## 📦 Requirements
- Apache or Nginx
- PHP 7.4+
- SQLite3
- unzip

## 🚀 Deployment Steps (Apache example)
1. Upload the contents of this folder to your server, e.g. `/var/www/html/link_storage/`
2. Set permissions for SQLite:
   sudo chown -R www-data:www-data /var/www/html/link_storage
   sudo chmod 664 /var/www/html/link_storage/links.db
   (If `links.db` doesn’t exist yet, PHP will create it on login/register)

3. Make sure PHP SQLite extension is enabled:
   sudo apt install php php-sqlite3

4. Restart Apache:
   sudo systemctl restart apache2

5. Visit your site:
   http://yourdomain.com/link_storage/

## 👤 First User Setup
Visit `register.php` to create a new user.

## 🧼 Optional: Add .htaccess
To hide .php extensions and improve security, you can create a `.htaccess` file:
```
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^([^\.]+)$ $1.php [NC,L]
```

## ✅ You're all set!
Login, add links, filter by tags, export as CSV, all with Bootstrap UI.
