<?php
session_start();
require 'db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$search = $_GET['search'] ?? '';
$filter_tag = $_GET['tag'] ?? '';

// Add new link
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['title'] && $_POST['url']) {
    $stmt = $db->prepare("INSERT INTO links (title, url, tags, user_id) VALUES (?, ?, ?, ?)");
    $stmt->execute([$_POST['title'], $_POST['url'], $_POST['tags'], $user_id]);
    header("Location: index.php");
    exit;
}

// Delete
if (isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM links WHERE id = ? AND user_id = ?");
    $stmt->execute([$_GET['delete'], $user_id]);
    header("Location: index.php");
    exit;
}

// Fetch tags for filter dropdown
$tags_stmt = $db->prepare("SELECT DISTINCT tags FROM links WHERE user_id = ?");
$tags_stmt->execute([$user_id]);
$tags_list = $tags_stmt->fetchAll(PDO::FETCH_COLUMN);

$links_query = "SELECT * FROM links WHERE user_id = ?";
$params = [$user_id];

if ($search) {
    $links_query .= " AND (title LIKE ? OR url LIKE ? OR tags LIKE ?)";
    $params = array_merge($params, ["%$search%", "%$search%", "%$search%"]);
}
if ($filter_tag) {
    $links_query .= " AND tags LIKE ?";
    $params[] = "%$filter_tag%";
}

$links_query .= " ORDER BY id DESC";
$stmt = $db->prepare($links_query);
$stmt->execute($params);
$links = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Link Storage</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h1>🔗 Link Storage</h1>
<a href="logout.php">Logout</a> | <a href="export.php">Export CSV</a>

<form method="POST">
    <input name="title" placeholder="Title" required>
    <input name="url" placeholder="https://..." required>
    <input name="tags" placeholder="Tags (comma-separated)">
    <button type="submit">Add</button>
</form>

<form method="GET">
    <input name="search" placeholder="Search..." value="<?= htmlspecialchars($search) ?>">
    <select name="tag">
        <option value="">All Tags</option>
        <?php foreach ($tags_list as $tag): ?>
            <option value="<?= htmlspecialchars($tag) ?>" <?= $filter_tag === $tag ? 'selected' : '' ?>>
                <?= htmlspecialchars($tag) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <button type="submit">🔍</button>
</form>

<ul>
<?php foreach ($links as $link): ?>
    <li>
        <a href="<?= htmlspecialchars($link['url']) ?>" target="_blank"><?= htmlspecialchars($link['title']) ?></a>
        <small><?= htmlspecialchars($link['tags']) ?></small>
        <a class="delete" href="?delete=<?= $link['id'] ?>">🗑️</a>
    </li>
<?php endforeach; ?>
</ul>
</body>
</html>